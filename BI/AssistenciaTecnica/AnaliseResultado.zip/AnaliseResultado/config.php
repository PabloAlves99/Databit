<?php

$server = 'localhost';
$base = 'tinsei';
$usuarioBanco = 'sa';
$SenhaBanco = 'databit';